package com.axis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestcruddemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
